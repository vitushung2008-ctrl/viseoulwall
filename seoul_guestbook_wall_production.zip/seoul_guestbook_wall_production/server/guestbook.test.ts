import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock the DB helpers ──────────────────────────────
vi.mock("./db", () => ({
  insertGuestbookEntry: vi.fn().mockResolvedValue(undefined),
  getAllGuestbookEntries: vi.fn().mockResolvedValue([
    {
      id: 1,
      role: "학생",
      dream: "세계를 여행하고 싶어요.",
      location: "서울 강남역",
      likes: 0,
      createdAt: new Date("2025-01-01T00:00:00Z"),
    },
    {
      id: 2,
      role: "직장인",
      dream: "나만의 카페를 열고 싶어요.",
      location: "부산 해운대",
      likes: 0,
      createdAt: new Date("2025-01-02T00:00:00Z"),
    },
  ]),
  upsertUser: vi.fn(),
  getUserByOpenId: vi.fn(),
  getDb: vi.fn(),
}));

function createPublicCtx(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("guestbook.submit", () => {
  it("accepts valid role, dream, and location inputs", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.guestbook.submit({
      role: "학생",
      dream: "세계를 여행하고 싶어요.",
      location: "서울 강남역",
    });
    expect(result).toEqual({ success: true });
  });

  it("rejects empty role", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    await expect(
      caller.guestbook.submit({ role: "", dream: "꿈이 있어요.", location: "서울" })
    ).rejects.toThrow();
  });

  it("rejects empty dream", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    await expect(
      caller.guestbook.submit({ role: "학생", dream: "", location: "서울" })
    ).rejects.toThrow();
  });

  it("rejects empty location", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    await expect(
      caller.guestbook.submit({ role: "학생", dream: "꿈이 있어요.", location: "" })
    ).rejects.toThrow();
  });

  it("rejects role exceeding 500 chars", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    await expect(
      caller.guestbook.submit({ role: "a".repeat(501), dream: "꿈", location: "서울" })
    ).rejects.toThrow();
  });

  it("rejects dream exceeding 2000 chars", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    await expect(
      caller.guestbook.submit({ role: "학생", dream: "a".repeat(2001), location: "서울" })
    ).rejects.toThrow();
  });

  it("rejects location exceeding 500 chars", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    await expect(
      caller.guestbook.submit({ role: "학생", dream: "꿈", location: "a".repeat(501) })
    ).rejects.toThrow();
  });

  it("escapes HTML in role, dream, and location before storing", async () => {
    const { insertGuestbookEntry } = await import("./db");
    const mockInsert = vi.mocked(insertGuestbookEntry);
    mockInsert.mockClear();

    const caller = appRouter.createCaller(createPublicCtx());
    await caller.guestbook.submit({
      role: "<script>alert('xss')</script>",
      dream: "<img src=x onerror=alert(1)>",
      location: "<svg onload=alert(1)>",
    });

    expect(mockInsert).toHaveBeenCalledOnce();
    const callArg = mockInsert.mock.calls[0]![0];
    expect(callArg.role).not.toContain("<script>");
    expect(callArg.dream).not.toContain("<img");
    expect(callArg.location).not.toContain("<svg");
    expect(callArg.role).toContain("&lt;");
    expect(callArg.dream).toContain("&lt;");
    expect(callArg.location).toContain("&lt;");
  });
});

describe("guestbook.list", () => {
  it("returns an array of entries", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.guestbook.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBe(2);
  });

  it("each entry has id, role, dream, location, likes, createdAt", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.guestbook.list();
    for (const entry of result) {
      expect(entry).toHaveProperty("id");
      expect(entry).toHaveProperty("role");
      expect(entry).toHaveProperty("dream");
      expect(entry).toHaveProperty("location");
      expect(entry).toHaveProperty("likes");
      expect(entry).toHaveProperty("createdAt");
    }
  });
});
