import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createRegularUserContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("guestbook.stats", () => {
  it("allows admin to access stats", async () => {
    const adminCtx = createAdminContext();
    const caller = appRouter.createCaller(adminCtx);

    const result = await caller.guestbook.stats();

    expect(result).toHaveProperty("totalCount");
    expect(result).toHaveProperty("totalLikes");
    expect(result).toHaveProperty("dailyStats");
    expect(result).toHaveProperty("topLocations");
    expect(result).toHaveProperty("topRoles");
  });

  it("denies regular user from accessing stats", async () => {
    const userCtx = createRegularUserContext();
    const caller = appRouter.createCaller(userCtx);

    let errorThrown = false;
    try {
      await caller.guestbook.stats();
    } catch (error: any) {
      errorThrown = true;
      expect(error.code).toBe("FORBIDDEN");
      expect(error.message).toContain("Admin access required");
    }
    expect(errorThrown).toBe(true);
  });
});
