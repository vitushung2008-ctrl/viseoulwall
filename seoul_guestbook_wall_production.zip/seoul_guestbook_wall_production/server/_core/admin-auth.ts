import type { Request, Response } from "express";
import { SignJWT, jwtVerify } from "jose";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./cookies";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "your-secret-key-change-in-production"
);

export type AdminSessionPayload = {
  isAdmin: true;
  iat: number;
  exp: number;
};

/**
 * 建立管理員 JWT token
 */
export async function createAdminToken(): Promise<string> {
  const token = await new SignJWT({ isAdmin: true })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("1y")
    .sign(JWT_SECRET);

  return token;
}

/**
 * 驗證管理員 JWT token
 */
export async function verifyAdminToken(token: string): Promise<AdminSessionPayload | null> {
  try {
    const verified = await jwtVerify(token, JWT_SECRET);
    return verified.payload as AdminSessionPayload;
  } catch {
    return null;
  }
}

/**
 * 從 request 中提取管理員 token
 */
export function getAdminTokenFromRequest(req: Request): string | null {
  const cookies = req.headers.cookie || "";
  const cookieObj = parseCookie(cookies);
  return cookieObj[COOKIE_NAME] || null;
}

/**
 * 簡單的 cookie 解析
 */
function parseCookie(cookieHeader: string): Record<string, string> {
  const result: Record<string, string> = {};
  cookieHeader.split(";").forEach((cookie) => {
    const [name, value] = cookie.trim().split("=");
    if (name && value) {
      result[name] = decodeURIComponent(value);
    }
  });
  return result;
}

/**
 * 管理員登入 API
 */
export async function handleAdminLogin(req: Request, res: Response) {
  const { password } = req.body;

  if (!password || password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Invalid password" });
    return;
  }

  try {
    const token = await createAdminToken();
    const cookieOptions = getSessionCookieOptions(req);
    res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
    res.json({ success: true });
  } catch (error) {
    console.error("[Admin Auth] Failed to create token:", error);
    res.status(500).json({ error: "Failed to create session" });
  }
}

/**
 * 管理員登出 API
 */
export async function handleAdminLogout(req: Request, res: Response) {
  const cookieOptions = getSessionCookieOptions(req);
  res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
  res.json({ success: true });
}

/**
 * 驗證管理員身份（用於 middleware）
 */
export async function verifyAdminFromRequest(req: Request): Promise<boolean> {
  const token = getAdminTokenFromRequest(req);
  if (!token) return false;
  const payload = await verifyAdminToken(token);
  return payload !== null && payload.isAdmin === true;
}
