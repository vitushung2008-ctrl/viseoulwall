import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createPublicContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("guestbook.toggleLike", () => {
  it("increments likes on valid entry", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // First, submit an entry
    await caller.guestbook.submit({
      role: "학생",
      dream: "세계 여행하기",
      location: "서울 강남역",
    });

    // Get the entries to find the ID
    const entries = await caller.guestbook.list();
    expect(entries.length).toBeGreaterThan(0);
    const entryId = entries[0]!.id;
    const initialLikes = entries[0]!.likes;

    // Toggle like
    const result = await caller.guestbook.toggleLike({ entryId });

    expect(result.success).toBe(true);
    expect(result.likes).toBe(initialLikes + 1);

    // Verify the like was persisted
    const updatedEntries = await caller.guestbook.list();
    const updatedEntry = updatedEntries.find(e => e.id === entryId);
    expect(updatedEntry?.likes).toBe(initialLikes + 1);
  });

  it("throws error for non-existent entry", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const nonExistentId = 999999;

    try {
      await caller.guestbook.toggleLike({ entryId: nonExistentId });
      expect.fail("Should have thrown an error");
    } catch (err: any) {
      expect(err.message).toContain("Entry not found");
    }
  });

  it("handles concurrent likes correctly (atomic increment)", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Submit an entry
    await caller.guestbook.submit({
      role: "직장인",
      dream: "성공하기",
      location: "서울 강남역",
    });

    const entries = await caller.guestbook.list();
    const entryId = entries[0]!.id;
    const initialLikes = entries[0]!.likes;

    // Simulate concurrent likes by calling toggleLike multiple times
    const results = await Promise.all([
      caller.guestbook.toggleLike({ entryId }),
      caller.guestbook.toggleLike({ entryId }),
      caller.guestbook.toggleLike({ entryId }),
    ]);

    // All should succeed
    expect(results.every(r => r.success)).toBe(true);

    // Verify final count is correct (atomic increment should prevent lost updates)
    const finalEntries = await caller.guestbook.list();
    const finalEntry = finalEntries.find(e => e.id === entryId);
    expect(finalEntry?.likes).toBe(initialLikes + 3);
  });
});
