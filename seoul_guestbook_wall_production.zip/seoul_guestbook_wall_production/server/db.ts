import { desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { GuestbookEntry, InsertGuestbookEntry, guestbookEntries } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;
let _client: ReturnType<typeof postgres> | null = null;

/**
 * Lazily create the drizzle instance so local tooling can run without a DB.
 */
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _client = postgres(process.env.DATABASE_URL);
      _db = drizzle(_client);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
      _client = null;
    }
  }
  return _db;
}

/**
 * Close database connection (for cleanup)
 */
export async function closeDb() {
  if (_client) {
    await _client.end();
    _client = null;
    _db = null;
  }
}

/**
 * Insert a new guestbook entry
 */
export async function insertGuestbookEntry(
  entry: InsertGuestbookEntry
): Promise<GuestbookEntry> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db
    .insert(guestbookEntries)
    .values(entry)
    .returning();
  
  return result[0] as GuestbookEntry;
}

/**
 * Get all visible guestbook entries, ordered by newest first
 */
export async function getAllGuestbookEntries(): Promise<GuestbookEntry[]> {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(guestbookEntries)
    .where(eq(guestbookEntries.isHidden, 0))
    .orderBy(desc(guestbookEntries.createdAt));
}

/**
 * Get all guestbook entries including hidden ones (admin only)
 */
export async function getAllGuestbookEntriesAdmin(): Promise<GuestbookEntry[]> {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(guestbookEntries)
    .orderBy(desc(guestbookEntries.createdAt));
}

/**
 * Toggle hidden status of an entry
 */
export async function toggleGuestbookEntryHidden(entryId: number): Promise<GuestbookEntry> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db
    .update(guestbookEntries)
    .set({
      isHidden: sql`CASE WHEN "isHidden" = 0 THEN 1 ELSE 0 END`,
    })
    .where(eq(guestbookEntries.id, entryId))
    .returning();
  
  return result[0] as GuestbookEntry;
}

/**
 * Delete a guestbook entry
 */
export async function deleteGuestbookEntry(entryId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .delete(guestbookEntries)
    .where(eq(guestbookEntries.id, entryId));
}

/**
 * Increment likes for an entry
 */
export async function incrementGuestbookEntryLikes(entryId: number): Promise<GuestbookEntry> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db
    .update(guestbookEntries)
    .set({
      likes: sql`"likes" + 1`,
    })
    .where(eq(guestbookEntries.id, entryId))
    .returning();
  
  return result[0] as GuestbookEntry;
}

/**
 * Get statistics about guestbook entries
 */
export async function getGuestbookStats() {
  const db = await getDb();
  if (!db) return null;
  
  const entries = await getAllGuestbookEntries();
  
  // Calculate daily stats
  const dailyStats: Record<string, number> = {};
  entries.forEach(entry => {
    const date = new Date(entry.createdAt).toISOString().split('T')[0];
    dailyStats[date] = (dailyStats[date] || 0) + 1;
  });
  
  // Get top locations
  const locationMap = new Map<string, number>();
  entries.forEach(entry => {
    locationMap.set(entry.location, (locationMap.get(entry.location) || 0) + 1);
  });
  const topLocations = Array.from(locationMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([location, count]) => ({ location, count }));
  
  // Get top roles
  const roleMap = new Map<string, number>();
  entries.forEach(entry => {
    roleMap.set(entry.role, (roleMap.get(entry.role) || 0) + 1);
  });
  const topRoles = Array.from(roleMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([role, count]) => ({ role, count }));
  
  const totalLikes = entries.reduce((sum, entry) => sum + entry.likes, 0);
  
  return {
    totalCount: entries.length,
    totalLikes,
    dailyStats,
    topLocations,
    topRoles,
  };
}
